package visualdebugger.draw2d;

import org.eclipse.draw2d.Label;
import org.eclipse.swt.graphics.Image;

public class BCLabel extends Label {

    public BCLabel() {
        // TODO Auto-generated constructor stub
    }

    public BCLabel(String s) {
        //if(true)
        super(s);
        // TODO Auto-generated constructor stub
    }

    public BCLabel(Image i) {
        super(i);
        // TODO Auto-generated constructor stub
    }

    public BCLabel(String s, Image i) {
        super(s, i);
        // TODO Auto-generated constructor stub
    }

}
